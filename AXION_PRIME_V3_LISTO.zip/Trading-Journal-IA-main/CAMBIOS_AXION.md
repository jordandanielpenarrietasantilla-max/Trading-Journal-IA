# Cambios aplicados

- Se eliminó `ui_v2/sidebar_completo.py` por ser duplicado.
- Se movió `bull_bear_futurista.png` a `assets/`.
- Se corrigió la ruta usada por `ui_v2/dashboard.py`.
- Se eliminó caché Python del proyecto.
- Se agregó configuración visual de Streamlit.
- Se agregó documentación de despliegue y secrets.
- Se verificó la sintaxis de todos los archivos Python.

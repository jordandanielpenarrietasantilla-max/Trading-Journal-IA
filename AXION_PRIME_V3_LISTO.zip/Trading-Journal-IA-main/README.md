# AXION PRIME X10 PRO

Trading journal en Streamlit con autenticación, almacenamiento y operaciones en Supabase.

## Estructura principal

- `app.py`: entrada de la aplicación.
- `core/`: configuración, API REST de Supabase, métricas, estado e imágenes.
- `ui/`: módulos funcionales existentes (registro, track record, herramientas e IA).
- `ui_v2/`: login, sidebar, dashboard y perfil premium.
- `assets/bull_bear_futurista.png`: arte visual del panel Bull vs Bear.

## Secrets requeridos en Streamlit

```toml
SUPABASE_URL = "..."
SUPABASE_KEY = "..."
OPENROUTER_API_KEY = "..."
OPENROUTER_MODEL = "google/gemini-2.5-flash"
ADMIN_EMAIL = "..."
APP_URL = "https://tu-app.streamlit.app"
```

## Despliegue

1. Sube el contenido de esta carpeta a la raíz del repositorio.
2. Mantén `app.py` en la raíz.
3. Configura los secrets en Streamlit Cloud.
4. Ejecuta **Manage app → Reboot app**.

## Estado visual

- Fondo oscuro unificado sin franjas heredadas.
- Sidebar compacto con navegación completa.
- Market Stream animado.
- Sesiones de trading dentro del dashboard y como pantalla independiente.
- Panel de noticias listo para conectar una API económica real.
- Bull vs Bear futurista usando imagen local.
